<?php

require 'config/function.php';

if(isset($_POST['loginBtn']))
{
    $email = validate($_POST['email']);
    $password = validate($_POST['password']);

    if($email != '' && $password != '')
    {
        $query = "SELECT * FROM admins WHERE email='$email' LIMIT 1";
        $result = mysqli_query($conn, $query);
        if($result){
            if(mysqli_num_rows($result) == 1){
                $row = mysqli_fetch_assoc($result);
                $hasedPassword = $row['password'];

                if(!password_verify($password,$hasedPassword)){
                    redirect('login.php', 'Invalid Password');
                }

                if($row['is_ban'] == 1){
                    redirect('login.php', 'Your account has been banned. Contact your admin for more enquiries');
                }

                $_SESSION['loggedInUser'] = [
                    'user_id' => $row['id'],
                    'username' => $row['username'],
                    'firstname' => $row['firstname'],
                    'lastname' => $row['lastname'],
                    'email' => $row['email'],
                    'phone' => $row['phone'],
                    'acct_bal' => $row['acct_bal'],
                    'admin_otp' => $row['admin_otp'],
                    'gender' => $row['gender'],
                ];
                header('Location: otp.php');
                
            }else{
                redirect('login.php', 'Invalid Email Address!');
            }
        }else{
            redirect('login.php', 'Something Went Wrong!');
        }
    }
    else
    {
        redirect('login.php', 'All fields are mandetory');
    }
}

?>