<?php include('includes/header.php'); ?>

<!-- Navbar -->
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="false" style="background: #495057; border-radius: 15px;">
    <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-gray-500" style="text-decoration: none;" href="index.php">Home</a></li>
            <li class="breadcrumb-item text-sm text-white active" aria-current="page">Main Admins</li>
        </ol>
        <h6 class="font-weight-bolder text-white mb-0">Main Admins</h6>
        </nav>
    </div>
</nav>
<!-- End Navbar -->

<div class="container-fluid px-4">
    <div class="card mt-4 shadow-sm">
        <div class="card-header">
            <h5 class="m-0 font-weight-bold" style="color: #495057">Main Admins/Staff
                <a href="main-admins-create.php" class="btn float-end text-white" style="background: #495057;">Add Main Admin</a>
            </h5>
        </div>
        <div class="card-body">

            <?php alertMessage(); ?>

            <?php
                // $admins = getAll('main_admin');
                $admin_type = 'admin';
                $query = "SELECT * FROM admins WHERE admin_type='$admin_type'";
                $admins = mysqli_query($conn, $query);
                if(!$admins){
                    echo "<h4>Something Went Wrong!</h4>";
                    return false;
                }
                if(mysqli_num_rows($admins) > 0){
                    
            ?>

            <div class="table-responsive">
                <table id="dataTable" class="table table-striped table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>USERNAME</th>
                            <th>EMAIL</th>
                            <th>Is Ban</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($admins as $adminItem) : ?>
                            <tr>
                                <td><?= $adminItem['id'] ?></td>
                                <td><?= $adminItem['username'] ?></td>
                                <td><?= $adminItem['email'] ?></td>
                                <td>
                                    <?php  
                                        if($adminItem['is_ban'] == 1){
                                            echo '<span class="badge bg-danger">Banned</span>';
                                        }else{
                                            echo '<span class="badge bg-primary">Active</span>';
                                        }
                                    ?>
                                </td>
                                <td>
                                    <a href="main-admins-edit.php?id=<?= $adminItem['id'] ?>" class="btn btn-success btn-sm">Edit</a>
                                    <a href="main-admins-delete.php?id=<?= $adminItem['id'] ?>"
                                         class="btn btn-danger btn-sm"
                                         onclick="return confirm('Are you sure you want to delete this Admin')"
                                    >
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php 
                }else{
                    ?>
                        <tr>
                            <h4 class="mb-0">No Record found</h4>
                        </tr>
                    <?php
                }
            ?>

        </div>
    </div>
</div> 

<?php include('includes/footer.php'); ?>